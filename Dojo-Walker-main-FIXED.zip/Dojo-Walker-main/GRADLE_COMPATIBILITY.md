# Dojo Walker Android Gradle compatibility

This project intentionally uses the modern Flutter Gradle Plugin DSL while keeping Gradle 7.5 as requested.

- Gradle: 7.5
- Android Gradle Plugin: 7.4.2
- Kotlin Gradle Plugin: 1.8.22
- Java: 17
- Flutter: 3.22.0 (CI)

AGP 7.4.x is paired with Gradle 7.5. AGP 8.1.x requires Gradle 8.0 or newer, so AGP 8.1.0 from the previous project was replaced rather than keeping an incompatible Gradle 7.5 wrapper.
